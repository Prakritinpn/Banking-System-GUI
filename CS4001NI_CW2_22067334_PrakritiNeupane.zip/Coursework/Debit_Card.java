
/**
 * Write a description of class Debit_Card here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Debit_Card extends Bank_Card
{

// declaring private attributes of class Debit_Card
private int pin_Number;
private int withdrawlAmount;
private String dateofWithdrawl;
private boolean hasWithdrawn;
//initialising the constructor
public Debit_Card(String clientName, String issuerBank, String bankAccount, int
card_id, int balanceAmount, int pin_Number)
{
super(clientName,issuerBank, bankAccount, card_id, balanceAmount);
super.setClientName(clientName);
this.pin_Number = pin_Number;
this.withdrawlAmount = withdrawlAmount;
this.hasWithdrawn = false;
}
//getters:convention
//public return-type getNn()
public int getPinNumber(){
    return this. pin_Number;
}

public int getWithdrawlAmount()
{
return this. withdrawlAmount;
}

public String getDateofWithdrawl()
{
return this. dateofWithdrawl;
}

public boolean getHasWithdrawn()
{
return this.hasWithdrawn;
}
//setters:convention
//public void setmm()
public void setWithdrawlAmount(int withdrawlAmount)
{
this.withdrawlAmount = withdrawlAmount;
}

 public void withdraw(int withdrawlAmount,String dateofWithdrawl,int pin$Number)
{
if(pin$Number == this.pin_Number) {
  if  (withdrawlAmount <= this.getBalanceAmount()) {

this.withdrawlAmount = withdrawlAmount;
this.dateofWithdrawl = dateofWithdrawl;
this.hasWithdrawn = true;
this.setBalanceAmount(this.getBalanceAmount() - withdrawlAmount);
}

else {

System.out.println("The pin_Number is valid");
}
}
else{
System.out.println("The pin_Number is invalid");
}
} public void display()
{
super.display();
if(hasWithdrawn == true) {
System.out.println("The pin number is;"+ this.pin_Number);
System.out.println("The withdrawl amount is;"+ this.withdrawlAmount);
System.out.println("The date of withdrawl is;"+ this.dateofWithdrawl);
}
else {
System.out.println("The balanceAmount is;"+getBalanceAmount());
}
}
}


