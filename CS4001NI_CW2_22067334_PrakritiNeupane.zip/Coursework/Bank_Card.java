
/**
 * Write a description of class Bank_Card here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Bank_Card
{
    // declaring attributes of class Bank_Card
    private String clientName;
    private String issuerBank;
    private String bankAccount;
    private int card_id;
    private int balanceAmount;
    //initialising the constructor
public Bank_Card(String clientName, String issuerBank,String bankAccount, int card_id, int balanceAmount)
{
   this.clientName="";
   this.issuerBank=issuerBank;
   this.bankAccount=bankAccount;
   this.card_id=card_id;
   this.balanceAmount=balanceAmount;
}
   //getters:convention
   //public return-type getNn()
   public String getClientName()
   {
       return this.clientName;
   }
   //setters:convention
   //public void setNn(int/String nn)
   public void setClientName(String clientName)
   {
       this.clientName = clientName;
   }
   public String getIssuerBank()
   {
       return this.issuerBank;
   }
   public void setIssuerBank(String issuerBank)
   {
       this.issuerBank=issuerBank;
   }
   public String getBankAccount()
   {
       return this.bankAccount;
   }
   public void setBankAccount(String bankAccount)
    {
       this.bankAccount=bankAccount;
    }
   public int getCardID()
   {
   return this.card_id=card_id;
   }
   public void setCardID(int card_id)
   {
     this.card_id=card_id;      
    }
   public int getBalanceAmount()
   {
    return this.balanceAmount;
   }
   public void setBalanceAmount(int balanceAmount)
   {
    this.balanceAmount=balanceAmount;
}
//display method to show the output
public void display(){
    if(clientName.equals("")) {
   
        System.out.println("The clients name hasnot been assigned yet");
    }
    else {
   
        System.out.print("The clients name has been assigned"+ clientName);
    }
    System.out.println("The bank account of the client is"+ bankAccount);
    System.out.println("The balance amount of the client is"+ balanceAmount);
    System.out.println("The Issuer Bank is"+ issuerBank);
    System.out.println("The Card id is"+ card_id);
    }

}
