
/**
 * Write a description of class BankGUI here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
//Importing necessary packages to develop the GUI.
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import java.util.ArrayList;

public class BankGUI implements ActionListener{

   //Declaring private variables that will be used to create the GUI.
   private JFrame jf;//The main window of the GUI.
   private JPanel pane,pane1,pane2,pane3,pane4,pane5;//Panels that are added to JFrame
            //Textfields were the user can enter the information.
   private JTextField tfCardID1,tfBankAccount2,tfIssuerBank3,tfPinNumber4,tfClientName5,tfBalanceAmnt6,tfCardID7,
           tfBankAccount8,tfIssuerBank9,tfIntRate10,tfClientName11,tfBalanceAmnt12,tfCvcNumber13,tfCardID14,tfWithdrawAmnt15,
           tfPinNumber16,tfCardID17,tfCreditLimit18,tfGracePeriod19,tfCardID20;
           //Labels that shows information to user.
   private JLabel lbl,lbl1,lbl2,lbl3,lbl4,lbl5,lbl6,lbl7,lbl8,lbl9,lbl10,lbl11,lbl12,lbl13,lbl14,lbl15,lbl16,lbl17,
           lbl18,lbl19,lbl20,lbl21,lbl22,lbl23,lbl24,lbl25;
           //Buttons that are clicked by user to perform action.
   private JButton btnDebitC1,btnCreditC2,btnAddDc3,btnWithdraw4,btnDisplay5,btnClear6,btnAddCc7,btnDisplay8,btnSetC9,
           btnCancel10,btnClear11,btnSubmit12,btnSet13,btnCancel14,btnBack15,btnBack16,btnBack17,btnBack18,btnBack19,btnClear20,
           btnClear21,btnClear22;
           //These are the dropdown menu ,from where the user can select options from a list.
   private JComboBox<String> expirationBox,expirationBox1,expirationBox2,
           withdrawBox3,withdrawBox4,withdrawBox5;
    
    //Creating an arraylist bank_list to store objects of Bank_Card.     
    private ArrayList <Bank_Card> bank_list;
    public BankGUI(){
        
        //Initializing a new JFrame object of title My Bank.
        jf = new JFrame("My Bank");
        bank_list = new ArrayList <Bank_Card>();
        
        //Creating new JPanel objects.
        pane = new JPanel();
        pane1 = new JPanel();
        pane2 = new JPanel();
        pane3 = new JPanel();
        pane4 = new JPanel();
        pane5 = new JPanel();
       
        
        //Setting layout of all the panels to null.
        pane.setLayout(null);
        pane1.setLayout(null);
        pane2.setLayout(null);
        pane3.setLayout(null);
        pane4.setLayout(null);
        pane5.setLayout(null);
        
        
        //Setting Background colour of the respective panels.
        pane.setBackground(Color.YELLOW);
        pane1.setBackground(Color.YELLOW);
        pane2.setBackground(Color.YELLOW);
        pane3.setBackground(Color.YELLOW);
        pane4.setBackground(Color.YELLOW);
        pane5.setBackground(Color.YELLOW);
        
        //Setting size of the panels.
        pane.setSize(700,550);
        pane1.setSize(700,550);
        pane2.setSize(700,550);
        pane3.setSize(700,550);
        pane4.setSize(700,550);
        pane5.setSize(700,550);
        
        
        //Creating new JLabel object.
        lbl = new JLabel("BANK CARD");
        lbl25 = new JLabel("*** Welcome, please select any one option ***");
        
        //Creating a new JButton objects with their respective labels.
        btnDebitC1 = new JButton("DEBIT CARD");
        btnCreditC2 = new JButton("CREDIT CARD");
        
        //Setting bounds of label and button.
        lbl.setBounds(224,11,180,36);
        lbl25.setBounds(112,108,456,36);
        
        btnDebitC1.setBounds(247,216,120,39);
        btnCreditC2.setBounds(247,342,120,39);
        
        //Setting new font for label lbl and lbl25.
        lbl.setFont(new Font("ABeeZee",Font.BOLD,26));
        lbl25.setFont(new Font("ABeeZee",Font.BOLD,20));
        
    
        //adding all the components to the panel.
        pane.add(lbl);
        pane.add(lbl25);
        pane.add(btnDebitC1);
        pane.add(btnCreditC2);
        
        
       
        //Creating new JLabel ,JTextField ,JButton objects and setting the position and size of the components using setBounds method ,for second panel pane1.
        lbl1 = new JLabel("Debit Card");
        lbl2 = new JLabel("Card ID : ");
        lbl3 = new JLabel("Bank Account :");
        lbl4 = new JLabel("Issuer Bank :");
        lbl5 = new JLabel("PIN Number :");
        lbl6 = new JLabel("Client Name :");
        lbl7 = new JLabel("Balance Amount :");
        
        tfCardID1 = new JTextField();
        tfBankAccount2 = new JTextField();
        tfIssuerBank3 = new JTextField(); 
        tfPinNumber4 = new JTextField();
        tfClientName5 = new JTextField();
        tfBalanceAmnt6 = new JTextField();
        
        
        lbl1.setBounds(275,9,124,36);
        lbl2.setBounds(54,83,60,20);
        lbl3.setBounds(48,157,93,20);
        lbl4.setBounds(54,231,82,20);
        lbl5.setBounds(54,299,85,20);
        lbl6.setBounds(391,77,89,20);
        lbl7.setBounds(377,151,110,20);
        
        tfCardID1.setBounds(165,71,180,32);
        tfBankAccount2.setBounds(165,145,180,32);
        tfIssuerBank3.setBounds(165,219,180,32);
        tfPinNumber4.setBounds(165,293,180,32);
        tfClientName5.setBounds(496,74,180,32);
        tfBalanceAmnt6.setBounds(496,145,180,32);
        
        btnAddDc3 = new JButton("ADD DEBIT");
        btnWithdraw4= new JButton("WITHDRAW");
        btnDisplay5= new JButton("DISPLAY");
        btnClear6 = new JButton("CLEAR");
        btnBack18 = new JButton("Back");
        
        btnAddDc3.setBounds(377,241,120,32);
        btnWithdraw4.setBounds(139,389,120,32);
        btnDisplay5.setBounds(331,389,120,32);
        btnClear6.setBounds(523,389,120,32);
        btnBack18.setBounds(17,367,88,32);
        
        //Adding all the components to  pane1.
        pane1.add(lbl1);
        pane1.add(lbl2);
        pane1.add(lbl3);
        pane1.add(lbl4);
        pane1.add(lbl5);
        pane1.add(lbl6);
        pane1.add(lbl7);
        
        pane1.add(tfCardID1);
        pane1.add(tfBankAccount2);
        pane1.add(tfIssuerBank3);
        pane1.add(tfPinNumber4);
        pane1.add(tfClientName5);
        pane1.add(tfBalanceAmnt6);
        
        pane1.add(btnAddDc3);
        pane1.add(btnWithdraw4);
        pane1.add(btnDisplay5);
        pane1.add(btnClear6);
        pane1.add(btnBack18);
        
    
        //Creating new JLabel ,JTextField ,JButton objects and setting the position and size of the components using setBounds method ,for third panel pane2.
        lbl8 = new JLabel("Credit Card");
        lbl9 = new JLabel("Card ID :");
        lbl10 = new JLabel("Bank Account :");
        lbl11 = new JLabel("Issuer Bank :");
        lbl12 = new JLabel("Interest Rate :");
        lbl13 = new JLabel("Expiration Date :");
        lbl14 = new JLabel("Client Name :");
        lbl15 = new JLabel("Balance Amount :");
        lbl16 = new JLabel("CVC Number :");
        
        lbl8.setBounds(263,4,133,36);
        lbl9.setBounds(45,71,60,20);
        lbl10.setBounds(26,134,97,20);
        lbl11.setBounds(42,190,86,20);
        lbl12.setBounds(36,256,92,20);
        lbl13.setBounds(27,322,107,20);
        lbl14.setBounds(386,63,85,20);
        lbl15.setBounds(359,126,110,20);
        lbl16.setBounds(380,189,91,20);
        
        tfCardID7 = new JTextField();
        tfBankAccount8 = new JTextField();
        tfIssuerBank9 = new JTextField(); 
        tfIntRate10 = new JTextField();
        tfClientName11 = new JTextField();
        tfBalanceAmnt12= new JTextField();
        tfCvcNumber13 = new JTextField(); 
      
        
        tfCardID7.setBounds(134,63,180,28);
        tfBankAccount8.setBounds(134,126,180,28);
        tfIssuerBank9.setBounds(134,182,180,28);
        tfIntRate10.setBounds(134,250,180,28);
        tfClientName11.setBounds(480,60,180,28);
        tfBalanceAmnt12.setBounds(480,120,180,28);
        tfCvcNumber13.setBounds(480,180,180,28);
        
        btnAddCc7 = new JButton("ADD CREDIT");
        btnDisplay8= new JButton("DISPLAY");
        btnSetC9= new JButton("SET CREDIT");
        btnCancel10 = new JButton("CANCEL");
        btnClear11 = new JButton("CLEAR");
        btnBack19 = new JButton("Back");
    
        btnAddCc7.setBounds(20,382,120,32);
        btnDisplay8.setBounds(262,436,120,32);
        btnSetC9.setBounds(404,436,120,32);
        btnCancel10.setBounds(110,436,120,32);
        btnClear11.setBounds(545,436,120,32);
        btnBack19.setBounds(574,371,91,32);
        
        String[] day = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
        expirationBox = new JComboBox<>(day);
        expirationBox.setBounds(140,318,84,32);
        String[] month = {"January", "February", "March", "April", "May", "June", "July"," August", "September","October", "November", "December" };
        expirationBox1 = new JComboBox<>(month);
        expirationBox1.setBounds(263,318,80,32);
        String[] year = {"2015","2016","2017","2018","2019","2020","2021","2022","2023"};
        expirationBox2= new JComboBox<>(year);
        expirationBox2.setBounds(382,318,103,32);
        
        //Adding all the components to pane2
        pane2.add(lbl8);
        pane2.add(lbl9);
        pane2.add(lbl10);
        pane2.add(lbl11);
        pane2.add(lbl12);
        pane2.add(lbl13);
        pane2.add(lbl14);
        pane2.add(lbl15);
        pane2.add(lbl16);

        
        pane2.add(tfCardID7);
        pane2.add(tfBankAccount8);
        pane2.add(tfIssuerBank9); 
        pane2.add(tfIntRate10);
        pane2.add(tfClientName11);
        pane2.add(tfBalanceAmnt12);
        pane2.add(tfCvcNumber13);
        
        pane2.add(btnAddCc7);
        pane2.add(btnDisplay8);
        pane2.add(btnSetC9);
        pane2.add(btnCancel10);
        pane2.add(btnClear11);
        pane2.add(btnBack19);
       
        pane2.add(expirationBox);
        pane2.add(expirationBox1);
        pane2.add(expirationBox2);
        
        lbl1.setFont(new Font("ABeeZee",Font.BOLD,22));
        lbl8.setFont(new Font("ABeeZee",Font.BOLD,22));
        
        //Creating new JLabel ,JTextField ,JButton objects and setting the position and size of the components using setBounds method ,for fourth panel pane3.
        
        lbl17 = new JLabel("Card ID :");
        lbl18 = new JLabel("Withdrawal Amount :");
        lbl19 = new JLabel("PIN Number :");
        lbl20 = new JLabel("Withdrawal Date :");
        
        
        lbl17.setBounds(98,84,60,20);
        lbl18.setBounds(47,152,128,20);
        lbl19.setBounds(81,225,85,20);
        lbl20.setBounds(52,298,114,20);
        
   
        tfCardID14 = new JTextField();
        tfWithdrawAmnt15 = new JTextField();
        tfPinNumber16 = new JTextField();  
        
        tfCardID14.setBounds(199,72,180,32);
        tfWithdrawAmnt15.setBounds(199,146,180,32);
        tfPinNumber16.setBounds(199,220,180,32);
        
        String[] day1 = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
         withdrawBox3 = new JComboBox<>(day1);
        withdrawBox3.setBounds(199,294,89,32);
        String[] month1 = { "January", "February", "March", "April", "May", "June", "July"," August", "September","October", "November", "December" };
         withdrawBox4 = new JComboBox<>(month1);
        withdrawBox4.setBounds(321,294,89,32);
        String[] year1 = {"2015","2016","2017","2018","2019","2020","2021","2022","2023"};
         withdrawBox5= new JComboBox<>(year1);
        withdrawBox5.setBounds(443,294,111,32);
        
        btnSubmit12 = new JButton("SUBMIT");
        btnSubmit12.setBounds(79,353,120,32);
        
        btnBack17 = new JButton("Back");
        btnBack17.setBounds(523,431,120,32);
        
        
        btnClear22 = new JButton("CLEAR");
        btnClear22.setBounds(290,431,120,32);
        
        //Adding all the components to pane3.
        pane3.add(lbl17);
        pane3.add(lbl18);
        pane3.add(lbl19); 
        pane3.add(lbl20);
        pane3.add(tfCardID14);
        pane3.add(tfWithdrawAmnt15);
        pane3.add(tfPinNumber16);
        
        
        pane3.add(withdrawBox3);
        pane3.add(withdrawBox4);
        pane3.add(withdrawBox5);
        pane3.add(btnSubmit12);
        pane3.add(btnBack17);
        pane3.add(btnClear22);
        
        //Creating new JLabel ,JTextField ,JButton objects and setting the position and size of the components using setBounds method ,for fifth panel pane4.    
        lbl21 = new JLabel("Card ID :");
        lbl22 = new JLabel("Credit Limit :");
        lbl23 = new JLabel("Grace Period :");
        
        lbl21.setBounds(122,50,56,20);
        lbl22.setBounds(115,141,82,20);
        lbl23.setBounds(103,238,94,20);
        
        tfCardID17 = new JTextField();
        tfCreditLimit18 = new JTextField();
        tfGracePeriod19 = new JTextField();
        
        tfCardID17.setBounds(250,44,180,32);
        tfCreditLimit18.setBounds(250,135,180,32);
        tfGracePeriod19.setBounds(250,226,180,32);
        
        btnSet13 = new JButton("SET");
        btnSet13.setBounds(284,307,120,32);
        btnBack15 = new JButton("Back");
        btnBack15.setBounds(524,383,120,32);
        btnClear20 = new JButton("CLEAR");
        btnClear20.setBounds(55,383,120,32);
        
        //Adding all the components to pane4.
        pane4.add(lbl21);
        pane4.add(lbl22);
        pane4.add(lbl23); 
        pane4.add(tfCardID17);
        pane4.add(btnSet13);
        pane4.add(tfCreditLimit18);
        pane4.add(tfGracePeriod19);
        pane4.add(btnBack15);
        pane4.add(btnClear20);
        
    
        //Creating new JLabel ,JTextField ,JButton objects and setting the position and size of the components using setBounds method ,for sixth panel pane5.
        lbl24 = new JLabel("Card ID : ");
        lbl24.setBounds(169,145,103,34);
        lbl25 = new JLabel("**  Enter the same CardID as before to cancel CreditCard **");
        lbl25.setBounds(129,44,429,22);
        
        tfCardID20 = new JTextField();
        tfCardID20.setBounds(296,144,180,32);
        
        btnCancel14 = new JButton("CANCEL");
        btnCancel14.setBounds(296,277,120,32);
        
        btnBack16 = new JButton("Back");
        btnBack16.setBounds(534,376,120,32);
        btnClear21 = new JButton("CLEAR");
        btnClear21.setBounds(57,376,120,32);
        
        //Adding all the components to pane5.
        pane5.add(lbl24);
        pane5.add(btnCancel14);
        pane5.add(tfCardID20);
        pane5.add(lbl25);
        pane5.add(btnBack16);
        pane5.add(btnClear21);
        
        
        
        
        pane.setVisible(true);
        pane1.setVisible(false);
        pane2.setVisible(false);
        pane3.setVisible(false);
        pane4.setVisible(false);
        pane5.setVisible(false);
        
        
        //Adding all the panels to JFrame.
        jf.add(pane);
        jf.add(pane1);
        jf.add(pane2);
        jf.add(pane3);
        jf.add(pane4);
        jf.add(pane5);
       
        
        //Adding action listener to the buttons.
        btnDebitC1.addActionListener(this);
        btnCreditC2.addActionListener(this);
        btnAddDc3.addActionListener(this);
        btnWithdraw4.addActionListener(this);
        btnDisplay5.addActionListener(this);
        btnDisplay8.addActionListener(this);
        btnSetC9.addActionListener(this);
        btnClear6.addActionListener(this);
        btnAddCc7.addActionListener(this);
        btnCancel10.addActionListener(this);
        btnClear11.addActionListener(this);
        btnSubmit12.addActionListener(this);
        btnSet13.addActionListener(this);
        btnCancel14.addActionListener(this);
        btnBack15.addActionListener(this);
        btnBack16.addActionListener(this);
        btnBack17.addActionListener(this);
        btnBack18.addActionListener(this);
        btnBack19.addActionListener(this);
        btnClear20.addActionListener(this);
        btnClear21.addActionListener(this);
        btnClear22.addActionListener(this);
        
        //Setting layout of JFrame to null.
        jf.setLayout(null);
        //Making the JFrame visibility to true to make it visible on screen.
        jf.setVisible(true); 
        //Setting the size of JFrame to 700 pixels wide and 550 pixels tall.
        jf.setSize(700,550);
        //Setting the default close operation for Java so that the user can exit after clicking close button.
        jf.setDefaultCloseOperation(jf.EXIT_ON_CLOSE);
    }
    
    public void actionPerformed(ActionEvent e){
        if (e.getSource()==btnAddCc7){
            if(tfCardID7.getText().isEmpty() || tfBankAccount8.getText().isEmpty() || tfIssuerBank9.getText().isEmpty() || tfIntRate10.getText().isEmpty() ||
            tfClientName11.getText().isEmpty() || tfBalanceAmnt12.getText().isEmpty() || tfCvcNumber13.getText().isEmpty()){
              JOptionPane.showMessageDialog(jf,"The form is not filled!","Text Field Empty",JOptionPane.INFORMATION_MESSAGE);
         }
        else{
            try{
            
                 String clientName = tfClientName11.getText();
                 String issuerBank = tfIssuerBank9.getText();
                 String bankAccount = tfBankAccount8.getText();
                 int card_id = Integer.parseInt(tfCardID7.getText());
                 int balanceAmount = Integer.parseInt(tfBalanceAmnt12.getText());
                 int cvcNumber = Integer.parseInt(tfCvcNumber13.getText());
                 double interestRate = Double.parseDouble(tfIntRate10.getText());
                 String expirationDate = expirationBox.getSelectedItem().toString()+expirationBox1.getSelectedItem().toString()+expirationBox2.getSelectedItem().toString();
             
                 Bank_Card c_card = new Credit_Card(clientName,issuerBank, bankAccount, card_id, balanceAmount, cvcNumber, interestRate, expirationDate);
                 bank_list.add(c_card);
                JOptionPane.showMessageDialog(jf,"The form has been successfully filled !","Complete",JOptionPane.INFORMATION_MESSAGE);
            }catch(NumberFormatException ey){
                JOptionPane.showMessageDialog(jf,"Please enter valid inputs in all the fields!!","Invalid Inputs",JOptionPane.WARNING_MESSAGE);
            }     
            }}
        if (e.getSource()==btnAddDc3){
            if(tfCardID1.getText().isEmpty() || tfBankAccount2.getText().isEmpty() || tfIssuerBank3.getText().isEmpty() || tfPinNumber4.getText().isEmpty() || 
            tfClientName5.getText().isEmpty() || tfBalanceAmnt6.getText().isEmpty()){
              JOptionPane.showMessageDialog(jf,"The form is not filled!","Text Field Empty",JOptionPane.INFORMATION_MESSAGE);
         }
        else{
            try{
                 String clientName = tfClientName5.getText();
                 String issuerBank = tfIssuerBank3.getText();
                 String bankAccount = tfBankAccount2.getText();
                 int card_id = Integer.parseInt(tfCardID1.getText());
                 int balanceAmount = Integer.parseInt(tfBalanceAmnt6.getText());
                 int pin_Number = Integer.parseInt(tfPinNumber4.getText());
                 String dateofWithdrawal = withdrawBox3.getSelectedItem().toString()+withdrawBox4.getSelectedItem().toString()+withdrawBox5.getSelectedItem().toString();
             
                 Bank_Card d_card = new Debit_Card(clientName,issuerBank, bankAccount, card_id, balanceAmount,pin_Number );
                 bank_list.add(d_card);
                JOptionPane.showMessageDialog(jf,"The form has been successfully filled","Complete",JOptionPane.INFORMATION_MESSAGE);
            } catch(NumberFormatException ex){
                JOptionPane.showMessageDialog(jf,"Please enter valid inputs in all the fields!!","Invalid Inputs",JOptionPane.WARNING_MESSAGE);
            
            }
                
            }}
            if(e.getSource() == btnSubmit12){ 
                if(tfCardID14.getText().isEmpty() || tfWithdrawAmnt15.getText().isEmpty() || tfPinNumber16.getText().isEmpty()){
              JOptionPane.showMessageDialog(jf,"Kindly,fill all the textfield completely!!!","Text Field Empty",JOptionPane.WARNING_MESSAGE);
            }else{
                try{
                    int card_id = Integer.parseInt(tfCardID14.getText());
                    int withdrawalAmount = Integer.parseInt(tfWithdrawAmnt15.getText());
                    int pin_Number = Integer.parseInt(tfPinNumber16.getText());
                    String dateofWithdrawal = withdrawBox3.getSelectedItem().toString()+withdrawBox4.getSelectedItem().toString()+withdrawBox5.getSelectedItem().toString();
                    for(Bank_Card dcard:bank_list){
                        if (dcard instanceof Debit_Card){
                            if(card_id  == dcard.getCardID()) {
                                Debit_Card debitCard = (Debit_Card) dcard;
                             if(debitCard.getBalanceAmount() >= withdrawalAmount){
                                if(pin_Number == debitCard.getPinNumber()){
                                debitCard.withdraw(withdrawalAmount, dateofWithdrawal, pin_Number);
                                JOptionPane.showMessageDialog(jf,"The required amount has been successfully withdrawn.","Success",JOptionPane.INFORMATION_MESSAGE);
                             break;
                                }else{
                                      JOptionPane.showMessageDialog(jf,"You have entered wrong pin number","Invalid",JOptionPane.WARNING_MESSAGE);
                                      break;
                                }
                                
                                }else{
                                    JOptionPane.showMessageDialog(jf,"You currently dont have required amount","Invalid",JOptionPane.WARNING_MESSAGE);
                                    break;
                                }
                            }  else{
                                    JOptionPane.showMessageDialog(jf,"Kindly,enter valid card id to withdraw!","Invalid",JOptionPane.WARNING_MESSAGE);
                                }
                            }
                        }
            
                    }catch(NumberFormatException ep){
                
                 JOptionPane.showMessageDialog(jf,"Kindly enter valid input in all the fields!","Invalid Inputs",JOptionPane.WARNING_MESSAGE);
    
            }
        }
    }
                if(e.getSource() == btnSet13){ 
                if(tfCardID17.getText().isEmpty() || tfCreditLimit18.getText().isEmpty() || tfGracePeriod19.getText().isEmpty()){
              JOptionPane.showMessageDialog(jf,"Kindly,fill all the textfield completely!!!","Text Field Empty",JOptionPane.WARNING_MESSAGE);
            }else{
                try{
                    int card_id = Integer.parseInt(tfCardID17.getText());
                    int creditLimit = Integer.parseInt(tfCreditLimit18.getText());
                    int gracePeriod = Integer.parseInt(tfGracePeriod19.getText());
                    
                     for(Bank_Card ccard:bank_list){
                        if (ccard instanceof Credit_Card){
                            if(card_id == ccard.getCardID()){
                              Credit_Card  credit_c= (Credit_Card) ccard;
                                
                              credit_c.setCreditLimit(creditLimit,gracePeriod);
                                JOptionPane.showMessageDialog(jf,"The credit limit has been set!","Success",JOptionPane.INFORMATION_MESSAGE);
                            } else{
                                JOptionPane.showMessageDialog(jf,"Kindly,enter valid card id !","Invalid Input",JOptionPane.WARNING_MESSAGE);
                                break;
                }
            }
            }
            } catch(NumberFormatException ez) {
               JOptionPane.showMessageDialog(jf,"Please,enter valid texts in the fields!","Invalid",JOptionPane.WARNING_MESSAGE);
        }
    }
}
     if(e.getSource() == btnCancel14){ 
                if(tfCardID20.getText().isEmpty()){
              JOptionPane.showMessageDialog(jf,"Please enter the card id!","Text Field Empty",JOptionPane.INFORMATION_MESSAGE);
            }else{
                try{
                    int card_id = Integer.parseInt(tfCardID20.getText());
                    for (Bank_Card cancredit: bank_list){
                        if(cancredit instanceof Credit_Card && card_id == cancredit.getCardID()){
                            Credit_Card cardC =(Credit_Card) cancredit;
                            cardC.cancelCreditCard();
                            JOptionPane.showMessageDialog(jf,"Your credit card has been canceled","Complete",JOptionPane.INFORMATION_MESSAGE);
                            } else{
                                JOptionPane.showMessageDialog(jf,"Kindly,enter valid card id!!!","Invalid Input",JOptionPane.WARNING_MESSAGE);
                                break;
                        }
                    }
                    
              } catch(NumberFormatException eq) {
                  JOptionPane.showMessageDialog(jf,"Please,enter valid numeric value!","Invalid",JOptionPane.WARNING_MESSAGE);
        }
    }
}
    //Clicking btnDisplay5 will display all the values of Debit_Card
    if(e.getSource()==btnDisplay5){
        for(Bank_Card nk:bank_list){
            if(nk instanceof Debit_Card){
                Debit_Card debitD = (Debit_Card) nk;
                debitD.display();     
                break;
            }
        }
    }
    //Clicking btnDisplay8 will display all the values of Credit_Card
    if(e.getSource()==btnDisplay8){
        for(Bank_Card ca:bank_list){
            if(ca instanceof Credit_Card){
                Credit_Card creditC = (Credit_Card) ca;
                creditC.display();
                break;
            }
        }
    }
    //Clicking btnDebitC1  makes  panel pane1 visible and hides other panel
    if(e.getSource()==btnDebitC1){  
        pane1.setVisible(true);
        pane2.setVisible(false);
        pane.setVisible(false);
       
    } 
    //Clicking btnCreditC2  makes  panel pane2 visible and hides other panel
    else if(e.getSource()==btnCreditC2){  
        pane1.setVisible(false);
        pane2.setVisible(true);
        pane.setVisible(false);  
         
    }
    //Clicking btnWithdraw4  makes  panel pane3 visible and hides other panel
    else if(e.getSource()==btnWithdraw4){ 
        pane3.setVisible(true);
        pane2.setVisible(false);
        pane1.setVisible(false);
        pane.setVisible(false);
    } 
    //Clicking btnSetC9  makes  panel pane4 visible and hides other panel
    else if(e.getSource()==btnSetC9){  
        pane1.setVisible(false);
        pane4.setVisible(true);
        pane2.setVisible(false);  
        pane3.setVisible(false);
        pane.setVisible(false);
    }
    //Clicking btnCancel10  makes  panel pane5 visible and hides other panel
    else if(e.getSource()==btnCancel10){  
        pane5.setVisible(true);
        pane1.setVisible(false);
        pane4.setVisible(false);
        pane2.setVisible(false);  
        pane3.setVisible(false);
        pane.setVisible(false);
    }
     //Clicking the back button in all the panel shows the main menu and hides other panels
    else if(e.getSource()==btnBack15){  
        pane5.setVisible(false);
        pane1.setVisible(false);
        pane4.setVisible(false);
        pane2.setVisible(true);  
        pane3.setVisible(false);
        pane.setVisible(false);
    }
    else if(e.getSource()==btnBack16){  
        pane5.setVisible(false);
        pane1.setVisible(false);
        pane4.setVisible(false);
        pane2.setVisible(true);  
        pane3.setVisible(false);
        pane1.setVisible(false);
    }
    else if(e.getSource()==btnBack17){  
        pane5.setVisible(false);
        pane1.setVisible(false);
        pane4.setVisible(false);
        pane2.setVisible(false);  
        pane3.setVisible(false);
        pane.setVisible(true);
    }
    else if(e.getSource()==btnBack18){  
        pane5.setVisible(false);
        pane1.setVisible(false);
        pane4.setVisible(false);
        pane2.setVisible(false);  
        pane3.setVisible(false);
        pane.setVisible(true);
    }
    else if(e.getSource()==btnBack19){  
        pane5.setVisible(false);
        pane1.setVisible(true);
        pane4.setVisible(false);
        pane2.setVisible(false);  
        pane3.setVisible(false);
        pane.setVisible(false);
    }
    //Clicking the clear button in different panels will reset the textfield to its default value
    else if(e.getSource() == btnClear6){
        tfCardID1.setText("");
        tfBankAccount2.setText("");
        tfIssuerBank3.setText("");
        tfPinNumber4.setText("");
        tfClientName5.setText("");
        tfBalanceAmnt6.setText("");        
    }
      else if(e.getSource() == btnClear11){
        tfCardID7.setText("");
        tfBankAccount8.setText("");
        tfIssuerBank9.setText("");
        tfIntRate10.setText("");
        tfClientName11.setText("");
        tfBalanceAmnt12.setText("");   
        tfCvcNumber13.setText(""); 
    }  
     else if(e.getSource() == btnClear20){
        tfCardID17.setText("");
        tfCreditLimit18.setText("");
        tfGracePeriod19.setText("");
        
    }  
    else if(e.getSource() == btnClear21){
        tfCardID20.setText("");
       
    }  
    else if(e.getSource() == btnClear22){
        tfCardID14.setText("");
        tfWithdrawAmnt15.setText("");
        tfPinNumber16.setText("");
    }  
   
}

public static void main (String[]args){
    //This line creates a new object of BankGUI called cardobj
    BankGUI cardobj = new BankGUI();
}
}

    




