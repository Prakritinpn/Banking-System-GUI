
/**
 * Write a description of class Credit_Card here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Credit_Card extends Bank_Card
{


    // declaring private attributes of class Credit_Card
    private int cvcNumber;
    private double creditLimit;
    private double interestRate;
    private String expirationDate;
    private int gracePeriod;
    private boolean isGranted;
     //initialising the constructor
     public Credit_Card( String clientName,String issuerBank,String bankAccount,int card_id,int balanceAmount,int cvcNumber,double interestRate,String expirationDate)
   
    {
        super(clientName,issuerBank,bankAccount,card_id,balanceAmount);
        setClientName(clientName);
        this.cvcNumber = cvcNumber;
        this.interestRate = interestRate;
        this.expirationDate = expirationDate;
        this.isGranted = false;
    }
     //getters:convention
     //public return-type getNn()
    public int getCvcNumber()
    {
        return this. cvcNumber;
    }

    public double getCreditLimit()
    {
        return this. creditLimit;
    }

    public double getInterestRate()
    {
        return this.interestRate;
    }

    public String getExpirationDate()
    {
        return this. expirationDate;
    }

    public int getGracePeriod()
    {
        return this. gracePeriod;
    }

    public boolean getIsGranted()
    {
        return this. isGranted;
    }

    public void setCreditLimit(double newCreditLimit,int newGracePeriod)
    {
        if(newCreditLimit <= (2.5*getBalanceAmount())){
            this.creditLimit = newCreditLimit;
            this.gracePeriod = newGracePeriod;
            this.isGranted = true;
        }
        else{
       
            System.out.println("The credit cannot be issued");
        }
    }

    public void cancelCreditCard()
    {
        this.cvcNumber = 0;
        this.gracePeriod = 0;
        this.creditLimit = 0;
        this.isGranted = false;
    }

    public void display()
    {
        if(isGranted == true) {
       
            super.display();
            System.out.println("The cvcNumber is"+ cvcNumber);
            System.out.println("The creditLimit is"+ creditLimit);
            System.out.println("The gracePeriod is"+ gracePeriod);
        }
        else{
       
            super.display();
            System.out.println("The cvcNumber is "+ this.cvcNumber);
        }
    }
}


